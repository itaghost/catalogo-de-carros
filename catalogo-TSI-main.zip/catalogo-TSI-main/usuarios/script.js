// Função para buscar e exibir o catálogo de veículos
async function displayCatalog() {
    const catalogList = document.getElementById("catalog-list");
    catalogList.innerHTML = "";

    try {
        const response = await fetch("http://localhost:3000/vehicles");
        const vehicles = await response.json();

        vehicles.forEach(vehicle => {
            const vehicleCard = document.createElement("div");
            vehicleCard.className = "card-item";
            vehicleCard.innerHTML = `
                <img src="${vehicle.image}" alt="${vehicle.name}" style="width: 100%; border-radius: 8px;" />
                <h3>${vehicle.name}</h3>
                <p>${vehicle.description}</p>
                <p>R$ ${vehicle.price}</p>
                <button onclick="viewVehicleDetails('${vehicle._id}')">Quero Este</button>
            `;
            catalogList.appendChild(vehicleCard);
        });
    } catch (error) {
        console.error("Erro ao carregar o catálogo:", error);
    }
}

// Função para redirecionar para a página de detalhes do veículo
function viewVehicleDetails(id) {
    window.location.href = `http://localhost:3000/vehicles/details?id=${id}`;
}


// Inicializa o catálogo na página pública
displayCatalog();
