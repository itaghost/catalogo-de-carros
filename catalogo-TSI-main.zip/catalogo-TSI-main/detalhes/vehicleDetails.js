// detalhes/vehicleDetails.js

async function fetchVehicleDetails() {
    // Obtém o ID do veículo da URL
    const params = new URLSearchParams(window.location.search);
    const id = params.get("id");

    if (!id) {
        console.error("ID do veículo não encontrado na URL.");
        return;
    }

    try {
        const response = await fetch(`http://localhost:3000/api/vehicles/${id}`);
        if (!response.ok) {
            throw new Error("Erro ao buscar dados do veículo");
        }
        const vehicle = await response.json();

        document.getElementById("vehicle-image").src = vehicle.image || "default-image.jpg";
        document.getElementById("vehicle-name").textContent = vehicle.name || "Nome não disponível";
        document.getElementById("vehicle-description").textContent = vehicle.description || "Descrição não disponível";
        document.getElementById("vehicle-price").textContent = vehicle.price || "Preço não disponível";
        document.getElementById("vehicle-year").textContent = vehicle.year || "Ano não disponível";
        document.getElementById("vehicle-city").textContent = vehicle.city || "Cidade não disponível";
        document.getElementById("vehicle-body-type").textContent = vehicle.bodyType || "Tipo não disponível";
        document.getElementById("vehicle-transmission").textContent = vehicle.transmission || "Transmissão não disponível";
        document.getElementById("vehicle-fuel").textContent = vehicle.fuel || "Combustível não disponível";
        document.getElementById("vehicle-mileage").textContent = vehicle.mileage || "Quilometragem não disponível";
        document.getElementById("vehicle-licensed").textContent = vehicle.licensed ? "Sim" : "Não";
    } catch (error) {
        console.error("Erro ao carregar os detalhes do veículo:", error);
    }
}

// Chama a função para carregar os detalhes do veículo ao carregar a página
fetchVehicleDetails();
