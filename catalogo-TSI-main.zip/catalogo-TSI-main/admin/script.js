let currentEditIndex = -1; // Variável para rastrear se estamos editando um veículo

// Função para exibir os veículos
async function displayVehicles() {
    const vehicleList = document.getElementById("vehicle-list");
    vehicleList.innerHTML = "";

    try {
        const response = await fetch("http://localhost:3000/vehicles");
        const vehicles = await response.json();

        vehicles.forEach(vehicle => {
            const vehicleItem = document.createElement("div");
            vehicleItem.className = "list-item";
            vehicleItem.innerHTML = `
                <img src="${vehicle.image}" alt="Veículo" style="width: 100%; height: auto; border-radius: 8px;" />
                <h4>${vehicle.name}</h4>
                <p>${vehicle.description}</p>
                <p>R$ ${vehicle.price}</p>
                <button onclick="editVehicle('${vehicle._id}')">Editar</button>
                <button onclick="deleteVehicle('${vehicle._id}')">Excluir</button>
            `;
            vehicleList.appendChild(vehicleItem);
        });
    } catch (error) {
        console.error("Erro ao carregar os veículos:", error);
    }
}

// Função para deletar veículo
async function deleteVehicle(id) {
    try {
        await fetch(`http://localhost:3000/vehicles/${id}`, { method: "DELETE" });
        displayVehicles();
    } catch (error) {
        console.error("Erro ao deletar o veículo:", error);
    }
}

// Função para abrir o modal
function openAddModal() {
    const modalBg = document.getElementById("modal-bg");
    modalBg.style.display = "block";
    document.getElementById("modal-title").textContent = "Adicionar Veículo";

    // Limpar os campos de entrada ao abrir o modal
    document.getElementById("vehicle-name").value = "";
    document.getElementById("vehicle-description").value = "";
    document.getElementById("vehicle-price").value = "";
    document.getElementById("vehicle-year").value = "";
    document.getElementById("vehicle-city").value = "";
    document.getElementById("vehicle-body-type").value = "";
    document.getElementById("vehicle-transmission").value = "";
    document.getElementById("vehicle-fuel").value = "";
    document.getElementById("vehicle-mileage").value = "";
    document.getElementById("vehicle-licensed").checked = false;
    document.getElementById("vehicle-image").value = "";
    document.getElementById("image-preview").style.display = "none";

    currentEditIndex = -1; // Reseta o índice de edição
}

// Função para fechar o modal
function closeModal() {
    const modalBg = document.getElementById("modal-bg");
    modalBg.style.display = "none";
}

// Função para adicionar ou editar veículo
async function saveVehicle() {
    const formData = new FormData();
    formData.append("name", document.getElementById("vehicle-name").value);
    formData.append("description", document.getElementById("vehicle-description").value);
    formData.append("price", document.getElementById("vehicle-price").value);
    formData.append("year", document.getElementById("vehicle-year").value);
    formData.append("city", document.getElementById("vehicle-city").value);
    formData.append("bodyType", document.getElementById("vehicle-body-type").value);
    formData.append("transmission", document.getElementById("vehicle-transmission").value);
    formData.append("fuel", document.getElementById("vehicle-fuel").value);
    formData.append("mileage", document.getElementById("vehicle-mileage").value);
    formData.append("licensed", document.getElementById("vehicle-licensed").checked);

    const imageInput = document.getElementById("vehicle-image");
    if (imageInput.files[0]) {
        formData.append("image", imageInput.files[0]);
    }

    const method = currentEditIndex === -1 ? "POST" : "PUT";
    const url = currentEditIndex === -1
        ? "http://localhost:3000/vehicles"
        : `http://localhost:3000/vehicles/${currentEditIndex}`;

    try {
        await fetch(url, { method, body: formData });
        displayVehicles();
        closeModal();
    } catch (error) {
        console.error("Erro ao salvar o veículo:", error);
    }
}

// Função para editar um veículo
async function editVehicle(id) {
    currentEditIndex = id; // Define o índice de edição

    const response = await fetch(`http://localhost:3000/vehicles/${id}`);
    const vehicle = await response.json();

    document.getElementById("vehicle-name").value = vehicle.name;
    document.getElementById("vehicle-description").value = vehicle.description;
    document.getElementById("vehicle-price").value = vehicle.price;
    document.getElementById("vehicle-year").value = vehicle.year || "";
    document.getElementById("vehicle-city").value = vehicle.city || "";
    document.getElementById("vehicle-body-type").value = vehicle.bodyType || "";
    document.getElementById("vehicle-transmission").value = vehicle.transmission || "";
    document.getElementById("vehicle-fuel").value = vehicle.fuel || "";
    document.getElementById("vehicle-mileage").value = vehicle.mileage || "";
    document.getElementById("vehicle-licensed").checked = vehicle.licensed || false;
    document.getElementById("image-preview").src = vehicle.image;
    document.getElementById("image-preview").style.display = "block";

    openAddModal(); // Abre o modal
}

// Função inicial de exibição
displayVehicles();
