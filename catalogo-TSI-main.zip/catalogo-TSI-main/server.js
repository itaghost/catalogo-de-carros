const express = require("express");
const multer = require("multer");
const path = require("path");
const mongoose = require("mongoose"); 
const Vehicle = require("./database"); // Importa o modelo Vehicle do database.js

const app = express();
const PORT = 3000;

// Conexão com o MongoDB
const mongoURI = "mongodb://localhost:27017/catalog";
mongoose.connect(mongoURI, { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => console.log("Conectado ao MongoDB"))
  .catch(error => console.error("Erro ao conectar ao MongoDB:", error));

// Configuração do armazenamento de imagens com Multer
const storage = multer.diskStorage({
  destination: "./uploads",
  filename: (req, file, cb) => {
    cb(null, Date.now() + path.extname(file.originalname)); // Salva a imagem com um timestamp
  },
});
const upload = multer({ storage });

// Middleware
app.use(express.json());

// Servindo arquivos estáticos
app.use("/uploads", express.static(path.join(__dirname, "uploads")));
app.use(express.static(path.join(__dirname, "usuarios")));
app.use("/admin", express.static(path.join(__dirname, "admin")));
app.use("/detalhes", express.static(path.join(__dirname, "detalhes")));

// Rotas de Servidor

// Rota para página principal do usuário
app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "usuarios", "index.html"));
});

// Rota para página de administração
app.get("/admin", (req, res) => {
  res.sendFile(path.join(__dirname, "admin", "admin.html"));
});

// Rota para página de detalhes do veículo
app.get("/vehicles/details", (req, res) => {
  res.sendFile(path.join(__dirname, "detalhes", "vehicleDetails.html"));
});

// Rota API para buscar um veículo específico
app.get("/api/vehicles/:id", async (req, res) => {
  const { id } = req.params;

  try {
    if (!mongoose.Types.ObjectId.isValid(id)) {
      return res.status(400).json({ error: "ID inválido." });
    }

    const vehicle = await Vehicle.findById(id);
    if (!vehicle) return res.status(404).json({ error: "Veículo não encontrado." });
    res.json(vehicle);
  } catch (error) {
    res.status(500).json({ error: "Erro ao buscar detalhes do veículo." });
  }
});

// Rotas CRUD para veículos

// Obter todos os veículos
app.get("/vehicles", async (req, res) => {
  try {
    const vehicles = await Vehicle.find();
    res.json(vehicles);
  } catch (error) {
    res.status(500).json({ error: "Erro ao buscar veículos." });
  }
});

// Adicionar um novo veículo
app.post("/vehicles", upload.single("image"), async (req, res) => {
  const { name, description, price, year, city, bodyType, transmission, fuel, mileage, licensed } = req.body;

  if (!name || !description || !price) {
    return res.status(400).json({ error: "Campos obrigatórios estão faltando." });
  }

  const imagePath = req.file ? `/uploads/${req.file.filename}` : null;

  try {
    const newVehicle = await Vehicle.create({
      name,
      description,
      price: parseFloat(price),
      image: imagePath,
      year: year ? parseInt(year) : null,
      city,
      bodyType,
      transmission,
      fuel,
      mileage: mileage ? parseInt(mileage) : null,
      licensed: licensed === "true" || licensed === true
    });
    res.json(newVehicle);
  } catch (error) {
    res.status(500).json({ error: "Erro ao salvar veículo." });
  }
});

// Atualizar um veículo pelo ID
app.put("/vehicles/:id", upload.single("image"), async (req, res) => {
  const { id } = req.params;
  const { name, description, price, year, city, bodyType, transmission, fuel, mileage, licensed } = req.body;
  const imagePath = req.file ? `/uploads/${req.file.filename}` : null;

  try {
    if (!mongoose.Types.ObjectId.isValid(id)) {
      return res.status(400).json({ error: "ID inválido." });
    }

    const updatedVehicle = await Vehicle.findByIdAndUpdate(
      id,
      { name, description, price: parseFloat(price), image: imagePath, year, city, bodyType, transmission, fuel, mileage, licensed },
      { new: true, runValidators: true }
    );
    if (!updatedVehicle) return res.status(404).json({ error: "Veículo não encontrado." });
    res.json(updatedVehicle);
  } catch (error) {
    res.status(500).json({ error: "Erro ao atualizar veículo." });
  }
});

// Deletar um veículo pelo ID
app.delete("/vehicles/:id", async (req, res) => {
  const { id } = req.params;

  try {
    if (!mongoose.Types.ObjectId.isValid(id)) {
      return res.status(400).json({ error: "ID inválido." });
    }

    const result = await Vehicle.findByIdAndDelete(id);
    if (!result) {
      return res.status(404).send("Veículo não encontrado");
    }
    res.send("Veículo deletado com sucesso");
  } catch (error) {
    console.error("Erro ao deletar veículo:", error);
    res.status(500).send("Erro ao deletar veículo");
  }
});

// Iniciar o servidor
app.listen(PORT, () => {
  console.log(`Servidor rodando em http://localhost:${PORT}`);
});
