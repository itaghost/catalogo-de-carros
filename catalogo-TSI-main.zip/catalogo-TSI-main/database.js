// database.js
const mongoose = require("mongoose");

const mongoURI = "mongodb://localhost:27017/catalog"; // Atualize com a URI do MongoDB
mongoose.connect(mongoURI, { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => console.log("MongoDB conectado"))
  .catch(error => console.error("Erro de conexão com o MongoDB:", error));

const vehicleSchema = new mongoose.Schema({
  name: { type: String, required: true },
  description: { type: String, required: true },
  price: { type: Number, required: true },
  image: { type: String },
  year: { type: Number },
  city: { type: String },
  bodyType: { type: String },
  transmission: { type: String },
  fuel: { type: String },
  mileage: { type: Number },
  licensed: { type: Boolean }
});

const Vehicle = mongoose.model("Vehicle", vehicleSchema);

module.exports = Vehicle;
